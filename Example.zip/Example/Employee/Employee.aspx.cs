﻿// Code-behind file that defines event handlers for the Employee.
using System;
using System.Collections.Specialized; // for class ListDictionary

public partial class Employee : System.Web.UI.Page
{
    // Submit Button adds a new Employee entry to the database,
    // clears the form and displays the updated list of Employee entries
    protected void submitButton_Click( object sender, EventArgs e )
   {
        // execute an INSERT  statement to add a new entry to the      
        // Employee table in the Employee Access Data Source
        EmployeeDataSource.InsertCommand = 
            "INSERT INTO [Employees] (" +"[Category]" + ", " +"[FirstName]" + ", " + "[LastName]" + ", " +"[BaseSalary]" + ", " +"[TSA]" +") VALUES (" +

            ToSql(RadioButtonEmployeeType.Text) +", " +
            ToSql(FirstnameTxtBox.Text) + ", " +
            ToSql(LastnameTxtBox.Text) + ", " +
            ToSql(BaseSalaryTxtBox.Text) + ", " +
            ToSql(TSATxtBox.Text) + 

            ")";

  
        EmployeeDataSource.Insert();

        // clear the TextBoxes
        clearTextBoxes();

      // update the GridView with the new database table contents
      EmployeeGrid.DataBind();
   } // submitButton_Click

    // format a string value for SQL
    private string ToSql(string stringValue)
    {
        return "'" + stringValue.Replace("'", "''") + "'";
    }

    // clear the TextBoxes
    private void clearTextBoxes()
    {
        FirstnameTxtBox.Text = String.Empty;
        RadioButtonEmployeeType.SelectedValue = "Faculty";
        LastnameTxtBox.Text = String.Empty;
        BaseSalaryTxtBox.Text = String.Empty;
        TSATxtBox.Text = String.Empty;

    }

    // Clear Button clears the Web Form's TextBoxes
    protected void clearButton_Click( object sender, EventArgs e )
   {
        clearTextBoxes();
   } // clearButton_Click



} // end class Employee
